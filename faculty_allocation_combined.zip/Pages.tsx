
// ---- START OF Classromms.tsx ----

import React, { useState } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Card } from "@/components/ui/card";
import { School, User, Users } from "lucide-react";
import { toast } from "sonner";

type Seat = {
  id: string;
  studentName?: string;
  status: "available" | "occupied" | "blocked";
};

type ClassroomDetail = {
  id: string;
  name: string;
  rows: number;
  cols: number;
  supervisor?: string;
  seats: Seat[];
};

const ClassroomGrid = ({ classroom, onSeatClick }: { 
  classroom: ClassroomDetail;
  onSeatClick: (seatId: string) => void;
}) => (
  <div className="p-4">
    <div 
      className="grid gap-1" 
      style={{ 
        gridTemplateColumns: `repeat(${classroom.cols}, minmax(0, 1fr))` 
      }}
    >
      {classroom.seats.map((seat) => (
        <button
          key={seat.id}
          onClick={() => onSeatClick(seat.id)}
          className={`
            w-10 h-10 rounded-lg flex items-center justify-center text-xs font-medium
            transition-all duration-200 transform hover:scale-105
            ${seat.status === "occupied" ? "bg-accent/20 text-accent" : 
              seat.status === "blocked" ? "bg-gray-200 cursor-not-allowed" :
              "bg-gray-100 hover:bg-accent/10"}
          `}
          title={seat.studentName || "Available"}
        >
          {seat.studentName ? seat.studentName[0] : ""}
        </button>
      ))}
    </div>
  </div>
);

const Classrooms = () => {
  const [classrooms, setClassrooms] = useState<ClassroomDetail[]>([
    {
      id: "1",
      name: "Room 301",
      rows: 5,
      cols: 8,
      supervisor: "Dr. Smith",
      seats: Array.from({ length: 40 }, (_, i) => ({
        id: `seat-${i}`,
        status: Math.random() > 0.7 ? "occupied" : 
                Math.random() > 0.8 ? "blocked" : "available",
        studentName: Math.random() > 0.7 ? `Student ${i + 1}` : undefined,
      })),
    },
    {
      id: "2",
      name: "Room 302",
      rows: 4,
      cols: 6,
      supervisor: "Prof. Johnson",
      seats: Array.from({ length: 24 }, (_, i) => ({
        id: `seat-${i}`,
        status: Math.random() > 0.7 ? "occupied" : 
                Math.random() > 0.8 ? "blocked" : "available",
        studentName: Math.random() > 0.7 ? `Student ${i + 1}` : undefined,
      })),
    },
  ]);

  const handleSeatClick = (classroomId: string, seatId: string) => {
    setClassrooms(prev => prev.map(classroom => {
      if (classroom.id === classroomId) {
        return {
          ...classroom,
          seats: classroom.seats.map(seat => {
            if (seat.id === seatId && seat.status === "available") {
              toast.success("Seat assigned to new student");
              return {
                ...seat,
                status: "occupied",
                studentName: `New Student`,
              };
            }
            return seat;
          }),
        };
      }
      return classroom;
    }));
  };

  return (
    <DashboardLayout>
      <div className="space-y-8 animate-slide-in">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-semibold text-gray-900">Classroom Seating</h1>
          <div className="flex items-center space-x-4 text-sm text-gray-500">
            <span className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-accent/20 mr-2" />
              Occupied
            </span>
            <span className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-gray-200 mr-2" />
              Blocked
            </span>
            <span className="flex items-center">
              <div className="w-3 h-3 rounded-full bg-gray-100 mr-2" />
              Available
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {classrooms.map((classroom) => (
            <Card key={classroom.id} className="overflow-hidden">
              <div className="p-4 border-b border-gray-100">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-lg font-medium text-gray-900">
                      {classroom.name}
                    </h2>
                    <p className="text-sm text-gray-500 mt-1">
                      <User className="w-4 h-4 inline mr-1" />
                      Supervisor: {classroom.supervisor}
                    </p>
                  </div>
                  <School className="w-6 h-6 text-accent" />
                </div>
                <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
                  <span>
                    {classroom.seats.filter(s => s.status === "occupied").length} occupied
                  </span>
                  <span>
                    {classroom.seats.filter(s => s.status === "available").length} available
                  </span>
                </div>
              </div>
              <ClassroomGrid 
                classroom={classroom}
                onSeatClick={(seatId) => handleSeatClick(classroom.id, seatId)}
              />
            </Card>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Classrooms;

// ---- END OF Classromms.tsx ----


// ---- START OF Faculty.tsx ----

import React from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Users, School } from "lucide-react";
import { DragDropContext } from "react-beautiful-dnd";
import { toast } from "sonner";
import FacultyCard from "@/components/faculty/FacultyCard";
import ClassroomCard from "@/components/faculty/ClassroomCard";
import { useFacultyData } from "@/hooks/useFacultyData";

const Faculty = () => {
  const { facultyMembers, setFacultyMembers, classrooms, setClassrooms, loading } = useFacultyData();

  const handleDragEnd = (result: any) => {
    if (!result.destination) return;

    const { source, destination, draggableId } = result;
    
    if (destination.droppableId.startsWith('c')) {
      const faculty = facultyMembers.find(f => f.id === draggableId);
      const classroom = classrooms.find(c => c.id === destination.droppableId);
      
      if (faculty && classroom) {
        if (faculty.allocations >= faculty.maxLoad) {
          toast.error(`${faculty.name} has reached maximum supervision load`);
          return;
        }

        setClassrooms(prev => prev.map(c => {
          if (c.id === classroom.id) {
            return { ...c, supervisor: faculty };
          }
          return c;
        }));

        setFacultyMembers(prev => prev.map(f => {
          if (f.id === faculty.id) {
            return { ...f, allocations: f.allocations + 1 };
          }
          return f;
        }));

        toast.success(`${faculty.name} assigned to ${classroom.name}`);
      }
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-8 animate-slide-in">
        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
              <p className="mt-4 text-gray-500">Loading faculty and classroom data...</p>
            </div>
          </div>
        ) : (
          <DragDropContext onDragEnd={handleDragEnd}>
            <section>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-semibold text-gray-900">Faculty Allocation</h2>
                <div className="flex items-center space-x-2 text-sm text-gray-500">
                  <Users className="w-5 h-5" />
                  <span>Total Faculty: {facultyMembers.length}</span>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {facultyMembers.map((faculty, index) => (
                  <FacultyCard key={faculty.id} faculty={faculty} index={index} />
                ))}
              </div>
            </section>

            <section>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-semibold text-gray-900">Classroom Allocation</h2>
                <div className="flex items-center space-x-2 text-sm text-gray-500">
                  <School className="w-5 h-5" />
                  <span>Total Rooms: {classrooms.length}</span>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {classrooms.map((classroom) => (
                  <ClassroomCard key={classroom.id} classroom={classroom} />
                ))}
              </div>
            </section>
          </DragDropContext>
        )}
      </div>
    </DashboardLayout>
  );
};

export default Faculty;

// ---- END OF Faculty.tsx ----


// ---- START OF Index.tsx ----

import React, { useEffect, useState } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Calendar, Users, School, Clock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";

type DashboardStats = {
  totalTeachers: number;
  totalClasses: number;
  totalScheduleSlots: number;
  roomUtilization: number;
};

type ExamInfo = {
  subject: string;
  date: string;
  faculty: string;
  room: string;
};

const StatsCard = ({ icon: Icon, label, value, trend }: {
  icon: React.ElementType;
  label: string;
  value: string;
  trend?: string;
}) => (
  <div className="glass-card rounded-xl p-6 hover-lift">
    <div className="flex items-start justify-between">
      <div>
        <p className="text-sm font-medium text-gray-500">{label}</p>
        <h3 className="mt-1 text-2xl font-semibold text-gray-900">{value}</h3>
        {trend && (
          <p className="mt-1 text-sm text-green-600">{trend}</p>
        )}
      </div>
      <Icon className="w-8 h-8 text-accent" />
    </div>
  </div>
);

const UpcomingExam = ({ subject, date, faculty, room }: ExamInfo) => (
  <div className="glass-card rounded-lg p-4 hover-lift">
    <h4 className="font-medium text-gray-900">{subject}</h4>
    <div className="mt-2 space-y-1">
      <p className="text-sm text-gray-500 flex items-center">
        <Calendar className="w-4 h-4 mr-2" /> {date}
      </p>
      <p className="text-sm text-gray-500 flex items-center">
        <Users className="w-4 h-4 mr-2" /> {faculty}
      </p>
      <p className="text-sm text-gray-500 flex items-center">
        <School className="w-4 h-4 mr-2" /> {room}
      </p>
    </div>
  </div>
);

const LoadingSkeleton = () => (
  <div className="space-y-6">
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {Array.from({ length: 4 }).map((_, i) => (
        <Skeleton key={i} className="h-32 w-full" />
      ))}
    </div>
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {Array.from({ length: 3 }).map((_, i) => (
        <Skeleton key={i} className="h-40 w-full" />
      ))}
    </div>
  </div>
);

const Index = () => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [upcomingExams, setUpcomingExams] = useState<ExamInfo[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      setLoading(true);
      try {
        // Fetch total teachers
        const { count: teachersCount, error: teachersError } = await supabase
          .from('teachers')
          .select('*', { count: 'exact', head: true });

        if (teachersError) throw teachersError;

        // Fetch total classes
        const { count: classesCount, error: classesError } = await supabase
          .from('classes')
          .select('*', { count: 'exact', head: true });

        if (classesError) throw classesError;

        // Fetch schedule slots
        const { count: slotsCount, error: slotsError } = await supabase
          .from('schedule_slots')
          .select('*', { count: 'exact', head: true });

        if (slotsError) throw slotsError;

        // Calculate utilization (slots / (classes * 5 days * 8 hours)) as percentage
        const maxSlots = classesCount * 5 * 8; // classes * days * hours
        const utilization = maxSlots > 0 ? Math.round((slotsCount / maxSlots) * 100) : 0;

        setStats({
          totalTeachers: teachersCount || 0,
          totalClasses: classesCount || 0,
          totalScheduleSlots: slotsCount || 0,
          roomUtilization: utilization
        });

        // Generate upcoming exams from schedule data and teachers
        const { data: scheduleData, error: scheduleError } = await supabase
          .from('schedule_slots')
          .select(`
            id, 
            day_of_week, 
            start_time, 
            room_number,
            teacher:teacher_id(name, subject),
            class:class_id(name)
          `)
          .order('day_of_week')
          .order('start_time')
          .limit(3);

        if (scheduleError) throw scheduleError;

        if (scheduleData) {
          const examInfos = scheduleData.map(slot => {
            // Format day and time for display
            const timeStr = slot.start_time.substring(0, 5);
            
            return {
              subject: slot.teacher?.subject || 'Unassigned',
              date: `${slot.day_of_week}, ${timeStr}`,
              faculty: slot.teacher?.name || 'Unassigned',
              room: slot.room_number
            };
          });

          setUpcomingExams(examInfos);
        }
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
        toast.error('Failed to load dashboard data');
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  if (loading) {
    return (
      <DashboardLayout>
        <LoadingSkeleton />
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-8 animate-slide-in">
        <section>
          <h2 className="text-2xl font-semibold text-gray-900 mb-4">Overview</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatsCard 
              icon={Calendar}
              label="Schedule Slots"
              value={stats?.totalScheduleSlots.toString() || "0"}
              trend="From database"
            />
            <StatsCard 
              icon={Users}
              label="Faculty"
              value={`${stats?.totalTeachers || 0}`}
            />
            <StatsCard 
              icon={School}
              label="Classes"
              value={`${stats?.totalClasses || 0}`}
            />
            <StatsCard 
              icon={Clock}
              label="Room Utilization"
              value={`${stats?.roomUtilization || 0}%`}
              trend="Based on schedule"
            />
          </div>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-gray-900 mb-4">Upcoming Classes</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {upcomingExams.length > 0 ? (
              upcomingExams.map((exam, index) => (
                <UpcomingExam 
                  key={index}
                  subject={exam.subject}
                  date={exam.date}
                  faculty={exam.faculty}
                  room={exam.room}
                />
              ))
            ) : (
              <div className="col-span-3 py-8 text-center">
                <p className="text-muted-foreground">No upcoming classes scheduled.</p>
              </div>
            )}
          </div>
        </section>
      </div>
    </DashboardLayout>
  );
};

export default Index;

// ---- END OF Index.tsx ----


// ---- START OF NotFound.tsx ----
import { useLocation } from "react-router-dom";
import { useEffect } from "react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="text-center">
        <h1 className="text-4xl font-bold mb-4">404</h1>
        <p className="text-xl text-gray-600 mb-4">Oops! Page not found</p>
        <a href="/" className="text-blue-500 hover:text-blue-700 underline">
          Return to Home
        </a>
      </div>
    </div>
  );
};

export default NotFound;

// ---- END OF NotFound.tsx ----


// ---- START OF Shedule.tsx ----

import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import DashboardLayout from "@/components/layout/DashboardLayout";
import ScheduleCalendar from "@/components/schedule/ScheduleCalendar";
import ScheduleFilters from "@/components/schedule/ScheduleFilters";
import ScheduleStats from "@/components/schedule/ScheduleStats";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/components/ui/use-toast";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";

export type Schedule = {
  id: string;
  day_of_week: string;
  start_time: string;
  end_time: string;
  room_number: string;
  teacher: {
    id: string;
    name: string;
    subject: string;
    experience?: string;
    position?: string;
  };
  class: {
    id: string;
    name: string;
    grade_level: string;
  };
};

type Teacher = {
  id: string;
  name: string;
  subject: string;
  experience?: string;
  position?: string;
};

type Class = {
  id: string;
  name: string;
  grade_level: string;
};

const Schedule: React.FC = () => {
  const { toast } = useToast();
  const [selectedDay, setSelectedDay] = useState<string | null>(null);
  const [selectedTeacher, setSelectedTeacher] = useState<string | null>(null);
  const [selectedClass, setSelectedClass] = useState<string | null>(null);

  const { data: scheduleData, isLoading: scheduleLoading } = useQuery({
    queryKey: ["schedule", selectedDay, selectedTeacher, selectedClass],
    queryFn: async () => {
      let query = supabase
        .from("schedule_slots")
        .select(`
          id,
          day_of_week,
          start_time,
          end_time,
          room_number,
          teacher:teacher_id(id, name, subject, experience, position),
          class:class_id(id, name, grade_level)
        `)
        .order("start_time");

      if (selectedDay) {
        query = query.eq("day_of_week", selectedDay);
      }
      
      if (selectedTeacher) {
        query = query.eq("teacher_id", selectedTeacher);
      }
      
      if (selectedClass) {
        query = query.eq("class_id", selectedClass);
      }

      const { data, error } = await query;
      
      if (error) {
        console.error("Error fetching schedule data:", error);
        toast({
          title: "Error fetching schedule",
          description: error.message,
          variant: "destructive",
        });
        return [];
      }
      
      return data as Schedule[];
    },
  });

  const { data: teachers = [], isLoading: teachersLoading } = useQuery<Teacher[]>({
    queryKey: ["teachers"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("teachers")
        .select("id, name, subject, experience, position")
        .order("name");
      
      if (error) {
        console.error("Error fetching teachers:", error);
        toast({
          title: "Error fetching teachers",
          description: error.message,
          variant: "destructive",
        });
        return [];
      }
      
      return data;
    },
  });

  const { data: classes = [], isLoading: classesLoading } = useQuery<Class[]>({
    queryKey: ["classes"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("classes")
        .select("id, name, grade_level")
        .order("name");
      
      if (error) {
        console.error("Error fetching classes:", error);
        toast({
          title: "Error fetching classes",
          description: error.message,
          variant: "destructive",
        });
        return [];
      }
      
      return data;
    },
  });

  const isLoading = scheduleLoading || teachersLoading || classesLoading;

  const handleDayChange = (day: string | null) => {
    setSelectedDay(day === "_all" ? null : day);
  };

  const handleTeacherChange = (teacherId: string | null) => {
    setSelectedTeacher(teacherId === "_all" ? null : teacherId);
  };

  const handleClassChange = (classId: string | null) => {
    setSelectedClass(classId === "_all" ? null : classId);
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-bold">Schedule</h1>
          <p className="text-muted-foreground">
            View and manage class schedules across the week
          </p>
        </div>

        {scheduleLoading || teachersLoading || classesLoading ? (
          <div className="h-96 flex items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="md:col-span-1 space-y-6">
              <ScheduleFilters
                days={["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]}
                teachers={teachers}
                classes={classes}
                selectedDay={selectedDay}
                selectedTeacher={selectedTeacher}
                selectedClass={selectedClass}
                onDayChange={handleDayChange}
                onTeacherChange={handleTeacherChange}
                onClassChange={handleClassChange}
              />
              
              <ScheduleStats 
                totalSlots={scheduleData?.length || 0}
                uniqueTeachers={new Set(scheduleData?.map(s => s.teacher.id) || []).size}
                uniqueClasses={new Set(scheduleData?.map(s => s.class.id) || []).size}
              />
            </div>

            <div className="md:col-span-3">
              {scheduleData && scheduleData.length > 0 ? (
                <ScheduleCalendar scheduleData={scheduleData} />
              ) : (
                <div className="h-96 bg-muted/30 rounded-lg flex items-center justify-center">
                  <p className="text-lg text-muted-foreground">
                    No schedule data found. Try adjusting your filters.
                  </p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
};

export default Schedule;

// ---- END OF Shedule.tsx ----

