
// ---- START OF ClassroomCard.tsx ----
import React from "react";
import { Card } from "@/components/ui/card";
import { User, CalendarDays, School } from "lucide-react";
import { Droppable } from "react-beautiful-dnd";
import { Classroom } from "@/types/faculty";

interface ClassroomCardProps {
  classroom: Classroom;
  onDrop?: (facultyId: string) => void;
}

const ClassroomCard: React.FC<ClassroomCardProps> = ({ classroom, onDrop }) => (
  <Droppable droppableId={classroom.id}>
    {(provided) => (
      <div ref={provided.innerRef} {...provided.droppableProps}>
        <Card className="p-4 glass-card">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="font-medium text-gray-900">{classroom.name}</h3>
              <p className="text-sm text-gray-500 mt-1">
                <CalendarDays className="w-4 h-4 inline mr-1" />
                {classroom.examDate}
              </p>
            </div>
            <School className="w-5 h-5 text-accent" />
          </div>
          <div className="mt-3 space-y-2">
            <div className="flex justify-between text-sm text-gray-500">
              <span>Capacity</span>
              <span>{classroom.allocatedStudents}/{classroom.capacity}</span>
            </div>
            {classroom.supervisor && (
              <div className="flex items-center space-x-2 text-sm text-gray-500">
                <User className="w-4 h-4" />
                <span>{classroom.supervisor.name}</span>
                {classroom.supervisor.position && (
                  <span className="inline-flex items-center px-1.5 py-0.5 rounded-sm text-xs bg-primary/10 text-primary-foreground">
                    {classroom.supervisor.position}
                  </span>
                )}
              </div>
            )}
          </div>
          <div className="mt-4">
            <div className="grid grid-cols-8 gap-1">
              {Array.from({ length: classroom.capacity }).map((_, i) => (
                <div
                  key={i}
                  className={`w-4 h-4 rounded-sm ${
                    i < classroom.allocatedStudents
                      ? "bg-accent/20"
                      : "bg-gray-100"
                  } transition-colors duration-200 hover:bg-accent/40 cursor-pointer`}
                  title={`Seat ${i + 1}`}
                />
              ))}
            </div>
          </div>
          {provided.placeholder}
        </Card>
      </div>
    )}
  </Droppable>
);

export default ClassroomCard;
// ---- END OF ClassroomCard.tsx ----


// ---- START OF FacultyCard.tsx ----
import React from "react";
import { Card } from "@/components/ui/card";
import { User } from "lucide-react";
import { Draggable } from "react-beautiful-dnd";
import { Faculty } from "@/types/faculty";

interface FacultyCardProps {
  faculty: Faculty;
  index: number;
}

const FacultyCard: React.FC<FacultyCardProps> = ({ faculty, index }) => (
  <Draggable draggableId={faculty.id} index={index}>
    {(provided) => (
      <div
        ref={provided.innerRef}
        {...provided.draggableProps}
        {...provided.dragHandleProps}
      >
        <Card className="p-4 glass-card hover-lift">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-accent/10 rounded-lg">
              <User className="w-5 h-5 text-accent" />
            </div>
            <div>
              <h3 className="font-medium text-gray-900">{faculty.name}</h3>
              <p className="text-sm text-gray-500">{faculty.subject}</p>
              {faculty.position && (
                <span className="inline-flex items-center px-2 py-0.5 mt-1 rounded text-xs bg-primary/10 text-primary-foreground">
                  {faculty.position}
                </span>
              )}
            </div>
          </div>
          <div className="mt-3 flex items-center justify-between text-sm">
            <span className="text-gray-500">Allocated: {faculty.allocations}/{faculty.maxLoad}</span>
            {faculty.experience && (
              <span className="text-gray-500 text-xs">Exp: {faculty.experience}</span>
            )}
          </div>
        </Card>
      </div>
    )}
  </Draggable>
);

export default FacultyCard;
// ---- END OF FacultyCard.tsx ----


// ---- START OF ScheduleFilters.tsx ----
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";

type Teacher = {
  id: string;
  name: string;
  subject: string;
  experience?: string;
  position?: string;
};

type Class = {
  id: string;
  name: string;
  grade_level: string;
};

interface ScheduleFiltersProps {
  days: string[];
  teachers: Teacher[];
  classes: Class[];
  selectedDay: string | null;
  selectedTeacher: string | null;
  selectedClass: string | null;
  onDayChange: (day: string | null) => void;
  onTeacherChange: (teacherId: string | null) => void;
  onClassChange: (classId: string | null) => void;
}

const ScheduleFilters: React.FC<ScheduleFiltersProps> = ({
  days,
  teachers,
  classes,
  selectedDay,
  selectedTeacher,
  selectedClass,
  onDayChange,
  onTeacherChange,
  onClassChange,
}) => {
  // Function to truncate long subject names
  const formatSubject = (subject: string) => {
    return subject.length > 20 ? subject.substring(0, 20) + "..." : subject;
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle>Filters</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="day-filter">Day of Week</Label>
          <Select
            value={selectedDay || ""}
            onValueChange={(value) => onDayChange(value === "" ? null : value)}
          >
            <SelectTrigger id="day-filter">
              <SelectValue placeholder="All days" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="_all">All days</SelectItem>
              {days.map((day) => (
                <SelectItem key={day} value={day}>
                  {day}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="teacher-filter">Teacher</Label>
          <Select
            value={selectedTeacher || ""}
            onValueChange={(value) => onTeacherChange(value === "" ? null : value)}
          >
            <SelectTrigger id="teacher-filter">
              <SelectValue placeholder="All teachers" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="_all">All teachers</SelectItem>
              {teachers && teachers.length > 0 && teachers.map((teacher) => (
                <TooltipProvider key={teacher.id}>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <SelectItem value={teacher.id}>
                        {teacher.name} 
                        {teacher.position && <Badge variant="outline" className="ml-1 text-[10px]">{teacher.position}</Badge>}
                      </SelectItem>
                    </TooltipTrigger>
                    <TooltipContent side="right" className="max-w-sm space-y-1">
                      <p><strong>Subject:</strong> {teacher.subject}</p>
                      {teacher.experience && <p><strong>Experience:</strong> {teacher.experience}</p>}
                      {teacher.position && <p><strong>Position:</strong> {teacher.position}</p>}
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="class-filter">Class</Label>
          <Select
            value={selectedClass || ""}
            onValueChange={(value) => onClassChange(value === "" ? null : value)}
          >
            <SelectTrigger id="class-filter">
              <SelectValue placeholder="All classes" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="_all">All classes</SelectItem>
              {classes && classes.length > 0 && classes.map((cls) => (
                <SelectItem key={cls.id} value={cls.id}>
                  {cls.name} ({cls.grade_level})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardContent>
    </Card>
  );
};

export default ScheduleFilters;
// ---- END OF ScheduleFilters.tsx ----


// ---- START OF ScheduleStats.tsx ----
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar, Users, BookOpen } from "lucide-react";

interface ScheduleStatsProps {
  totalSlots: number;
  uniqueTeachers: number;
  uniqueClasses: number;
}

const ScheduleStats: React.FC<ScheduleStatsProps> = ({
  totalSlots,
  uniqueTeachers,
  uniqueClasses,
}) => {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle>Statistics</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-3">
          <div className="bg-primary/10 p-2 rounded-full">
            <Calendar className="h-5 w-5 text-primary" />
          </div>
          <div>
            <p className="text-sm font-medium">Total Time Slots</p>
            <p className="text-2xl font-bold">{totalSlots}</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-primary/10 p-2 rounded-full">
            <Users className="h-5 w-5 text-primary" />
          </div>
          <div>
            <p className="text-sm font-medium">Teachers Scheduled</p>
            <p className="text-2xl font-bold">{uniqueTeachers}</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-primary/10 p-2 rounded-full">
            <BookOpen className="h-5 w-5 text-primary" />
          </div>
          <div>
            <p className="text-sm font-medium">Classes Scheduled</p>
            <p className="text-2xl font-bold">{uniqueClasses}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ScheduleStats;
// ---- END OF ScheduleStats.tsx ----


// ---- START OF SheduleCalendar.tsx ----
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Schedule } from "@/pages/Schedule";
import { Badge } from "@/components/ui/badge";
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface ScheduleCalendarProps {
  scheduleData: Schedule[];
}

const timeSlots = [
  "08:00:00", "09:00:00", "10:00:00", "11:00:00", 
  "12:00:00", "13:00:00", "14:00:00", "15:00:00", "16:00:00"
];

const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];

const formatTime = (time: string) => {
  return time.substring(0, 5);
};

// Function to truncate long subject names
const formatSubject = (subject: string) => {
  return subject.length > 25 ? subject.substring(0, 25) + "..." : subject;
};

const ScheduleCalendar: React.FC<ScheduleCalendarProps> = ({ scheduleData }) => {
  const getScheduleForDayAndTime = (day: string, startTime: string) => {
    return scheduleData.filter(
      (schedule) => 
        schedule.day_of_week === day && 
        schedule.start_time === startTime
    );
  };

  // Group by day to check if we need to show particular days
  const scheduleByDay = days.reduce((acc, day) => {
    acc[day] = scheduleData.filter(s => s.day_of_week === day);
    return acc;
  }, {} as Record<string, Schedule[]>);

  // Filter out days with no schedule
  const daysWithSchedule = days.filter(day => scheduleByDay[day].length > 0);

  return (
    <Card>
      <CardContent className="p-0 overflow-x-auto">
        <div className="min-w-[800px]">
          <div className="grid grid-cols-[100px_repeat(auto-fill,minmax(140px,1fr))]">
            {/* Header row with days */}
            <div className="h-16 flex items-center justify-center font-medium bg-muted/50 border-b border-r">
              Time / Day
            </div>
            
            {daysWithSchedule.length > 0 ? (
              daysWithSchedule.map((day) => (
                <div 
                  key={day} 
                  className="h-16 flex items-center justify-center font-medium bg-muted/50 border-b"
                >
                  {day}
                </div>
              ))
            ) : (
              days.map((day) => (
                <div 
                  key={day} 
                  className="h-16 flex items-center justify-center font-medium bg-muted/50 border-b"
                >
                  {day}
                </div>
              ))
            )}

            {/* Time slots rows */}
            {timeSlots.slice(0, -1).map((time, i) => (
              <React.Fragment key={time}>
                {/* Time slot */}
                <div className="h-24 flex items-center justify-center font-medium text-sm border-r border-b">
                  {formatTime(time)}
                </div>
                
                {/* Schedule cells */}
                {(daysWithSchedule.length > 0 ? daysWithSchedule : days).map((day) => {
                  const schedules = getScheduleForDayAndTime(day, time);
                  return (
                    <div 
                      key={`${day}-${time}`}
                      className="h-24 border-b p-1 bg-card"
                    >
                      {schedules.length > 0 ? (
                        <div className="h-full flex flex-col gap-1 overflow-y-auto">
                          {schedules.map((schedule) => (
                            <TooltipProvider key={schedule.id}>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <div className="bg-primary/10 hover:bg-primary/20 transition-colors p-2 rounded-md text-xs cursor-default">
                                    <div className="font-medium">
                                      {schedule.class.name}
                                    </div>
                                    <div className="flex items-center gap-1 text-muted-foreground">
                                      <span>{schedule.teacher.name}</span>
                                      {schedule.teacher.position && (
                                        <Badge variant="outline" className="text-[9px]">
                                          {schedule.teacher.position}
                                        </Badge>
                                      )}
                                    </div>
                                    <div className="text-[10px] mt-0.5 text-primary-foreground/70 font-medium truncate">
                                      {formatSubject(schedule.teacher.subject)}
                                    </div>
                                    <div className="flex justify-between items-center mt-1">
                                      <Badge variant="outline" className="text-[10px]">
                                        {schedule.room_number}
                                      </Badge>
                                      <span className="text-[10px]">
                                        {formatTime(schedule.start_time)}-{formatTime(schedule.end_time)}
                                      </span>
                                    </div>
                                  </div>
                                </TooltipTrigger>
                                <TooltipContent className="max-w-sm">
                                  <div className="space-y-1.5">
                                    <p><strong>Class:</strong> {schedule.class.name} ({schedule.class.grade_level})</p>
                                    <p><strong>Teacher:</strong> {schedule.teacher.name}</p>
                                    {schedule.teacher.position && <p><strong>Position:</strong> {schedule.teacher.position}</p>}
                                    {schedule.teacher.experience && <p><strong>Experience:</strong> {schedule.teacher.experience}</p>}
                                    <p><strong>Subject:</strong> {schedule.teacher.subject}</p>
                                    <p><strong>Room:</strong> {schedule.room_number}</p>
                                    <p><strong>Time:</strong> {formatTime(schedule.start_time)} - {formatTime(schedule.end_time)}</p>
                                  </div>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          ))}
                        </div>
                      ) : null}
                    </div>
                  );
                })}
              </React.Fragment>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ScheduleCalendar;
// ---- END OF SheduleCalendar.tsx ----

