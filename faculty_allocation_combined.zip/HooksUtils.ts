
// ---- START OF use-mobile.tsx ----
import * as React from "react"

const MOBILE_BREAKPOINT = 768

export function useIsMobile() {
  const [isMobile, setIsMobile] = React.useState<boolean | undefined>(undefined)

  React.useEffect(() => {
    const mql = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`)
    const onChange = () => {
      setIsMobile(window.innerWidth < MOBILE_BREAKPOINT)
    }
    mql.addEventListener("change", onChange)
    setIsMobile(window.innerWidth < MOBILE_BREAKPOINT)
    return () => mql.removeEventListener("change", onChange)
  }, [])

  return !!isMobile
}
// ---- END OF use-mobile.tsx ----


// ---- START OF use-toast.tsx ----
import * as React from "react"

import type {
  ToastActionElement,
  ToastProps,
} from "@/components/ui/toast"

const TOAST_LIMIT = 1
const TOAST_REMOVE_DELAY = 1000000

type ToasterToast = ToastProps & {
  id: string
  title?: React.ReactNode
  description?: React.ReactNode
  action?: ToastActionElement
}

const actionTypes = {
  ADD_TOAST: "ADD_TOAST",
  UPDATE_TOAST: "UPDATE_TOAST",
  DISMISS_TOAST: "DISMISS_TOAST",
  REMOVE_TOAST: "REMOVE_TOAST",
} as const

let count = 0

function genId() {
  count = (count + 1) % Number.MAX_SAFE_INTEGER
  return count.toString()
}

type ActionType = typeof actionTypes

type Action =
  | {
      type: ActionType["ADD_TOAST"]
      toast: ToasterToast
    }
  | {
      type: ActionType["UPDATE_TOAST"]
      toast: Partial<ToasterToast>
    }
  | {
      type: ActionType["DISMISS_TOAST"]
      toastId?: ToasterToast["id"]
    }
  | {
      type: ActionType["REMOVE_TOAST"]
      toastId?: ToasterToast["id"]
    }

interface State {
  toasts: ToasterToast[]
}

const toastTimeouts = new Map<string, ReturnType<typeof setTimeout>>()

const addToRemoveQueue = (toastId: string) => {
  if (toastTimeouts.has(toastId)) {
    return
  }

  const timeout = setTimeout(() => {
    toastTimeouts.delete(toastId)
    dispatch({
      type: "REMOVE_TOAST",
      toastId: toastId,
    })
  }, TOAST_REMOVE_DELAY)

  toastTimeouts.set(toastId, timeout)
}

export const reducer = (state: State, action: Action): State => {
  switch (action.type) {
    case "ADD_TOAST":
      return {
        ...state,
        toasts: [action.toast, ...state.toasts].slice(0, TOAST_LIMIT),
      }

    case "UPDATE_TOAST":
      return {
        ...state,
        toasts: state.toasts.map((t) =>
          t.id === action.toast.id ? { ...t, ...action.toast } : t
        ),
      }

    case "DISMISS_TOAST": {
      const { toastId } = action

      // ! Side effects ! - This could be extracted into a dismissToast() action,
      // but I'll keep it here for simplicity
      if (toastId) {
        addToRemoveQueue(toastId)
      } else {
        state.toasts.forEach((toast) => {
          addToRemoveQueue(toast.id)
        })
      }

      return {
        ...state,
        toasts: state.toasts.map((t) =>
          t.id === toastId || toastId === undefined
            ? {
                ...t,
                open: false,
              }
            : t
        ),
      }
    }
    case "REMOVE_TOAST":
      if (action.toastId === undefined) {
        return {
          ...state,
          toasts: [],
        }
      }
      return {
        ...state,
        toasts: state.toasts.filter((t) => t.id !== action.toastId),
      }
  }
}

const listeners: Array<(state: State) => void> = []

let memoryState: State = { toasts: [] }

function dispatch(action: Action) {
  memoryState = reducer(memoryState, action)
  listeners.forEach((listener) => {
    listener(memoryState)
  })
}

type Toast = Omit<ToasterToast, "id">

function toast({ ...props }: Toast) {
  const id = genId()

  const update = (props: ToasterToast) =>
    dispatch({
      type: "UPDATE_TOAST",
      toast: { ...props, id },
    })
  const dismiss = () => dispatch({ type: "DISMISS_TOAST", toastId: id })

  dispatch({
    type: "ADD_TOAST",
    toast: {
      ...props,
      id,
      open: true,
      onOpenChange: (open) => {
        if (!open) dismiss()
      },
    },
  })

  return {
    id: id,
    dismiss,
    update,
  }
}

function useToast() {
  const [state, setState] = React.useState<State>(memoryState)

  React.useEffect(() => {
    listeners.push(setState)
    return () => {
      const index = listeners.indexOf(setState)
      if (index > -1) {
        listeners.splice(index, 1)
      }
    }
  }, [state])

  return {
    ...state,
    toast,
    dismiss: (toastId?: string) => dispatch({ type: "DISMISS_TOAST", toastId }),
  }
}

export { useToast, toast }

// ---- END OF use-toast.tsx ----


// ---- START OF useFacultyData.tsx ----

import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Faculty, Classroom } from "@/types/faculty";
import { toast } from "sonner";

export const useFacultyData = () => {
  const [facultyMembers, setFacultyMembers] = useState<Faculty[]>([]);
  const [classrooms, setClassrooms] = useState<Classroom[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const { data: teachersData, error: teachersError } = await supabase
          .from('teachers')
          .select('id, name, subject, position, experience')
          .order('name', { ascending: true });

        if (teachersError) throw teachersError;

        const facultyData = teachersData.map(teacher => ({
          id: teacher.id,
          name: teacher.name,
          subject: teacher.subject,
          department: teacher.subject.split(' ')[0],
          allocations: 0,
          maxLoad: 3,
          position: teacher.position || undefined,
          experience: teacher.experience || undefined
        }));

        setFacultyMembers(facultyData);

        const { data: classesData, error: classesError } = await supabase
          .from('classes')
          .select('id, name, grade_level')
          .order('name', { ascending: true });

        if (classesError) throw classesError;

        const classroomData = classesData.map((cls, index) => {
          const baseCapacity = cls.grade_level.includes('12th') ? 25 : 
                              cls.grade_level.includes('11th') ? 30 :
                              cls.grade_level.includes('10th') ? 35 : 40;
          
          const capacity = baseCapacity + Math.floor(Math.random() * 10);
          const allocatedStudents = capacity - Math.floor(Math.random() * 10);
          
          const day = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'][index % 5];
          const hour = 8 + (index % 8);
          const examDate = `${day}, ${hour}:00 AM`;
          
          return {
            id: cls.id,
            name: cls.name,
            capacity,
            allocatedStudents,
            examDate,
            supervisor: null
          };
        });

        if (facultyData.length > 0 && classroomData.length > 0) {
          classroomData[0].supervisor = facultyData[0];
          if (classroomData.length > 1 && facultyData.length > 1) {
            classroomData[1].supervisor = facultyData[1];
          }
          
          const updatedFaculty = [...facultyData];
          updatedFaculty[0].allocations = 1;
          if (facultyData.length > 1) {
            updatedFaculty[1].allocations = 1;
          }
          setFacultyMembers(updatedFaculty);
        }

        setClassrooms(classroomData);
      } catch (error) {
        console.error('Error fetching data:', error);
        toast.error('Failed to load data. Please try again.');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return {
    facultyMembers,
    setFacultyMembers,
    classrooms,
    setClassrooms,
    loading
  };
};

// ---- END OF useFacultyData.tsx ----


// ---- START OF utils.ts ----
import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// ---- END OF utils.ts ----

